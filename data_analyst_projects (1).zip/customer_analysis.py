
import pandas as pd

data = {
    "Name": ["Asha", "Rahul", "John", "Meena", "David"],
    "Age": [25, 30, 28, 35, 40],
    "City": ["Bangalore", "Mumbai", "Bangalore", "Delhi", "Mumbai"]
}

df = pd.DataFrame(data)

# Average age
print("Average Age:", df["Age"].mean())

# Customers per city
city_count = df["City"].value_counts()
print("\nCustomers by City:")
print(city_count)
