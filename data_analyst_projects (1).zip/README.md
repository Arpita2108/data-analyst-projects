
# Data Analyst Python Projects

This repository contains beginner **Data Analyst projects using Python**.

## Projects

### 1. Sales Data Analysis
- Uses Python and Pandas
- Calculates total sales
- Finds best selling product

Run:
python sales_analysis.py

### 2. Customer Data Analysis
- Analyzes customer age data
- Counts customers by city

Run:
python customer_analysis.py

### 3. Sales Visualization
- Creates a bar chart using matplotlib

Run:
python sales_visualization.py

## Tools Used
- Python
- Pandas
- Matplotlib

These projects demonstrate basic **data analysis, grouping, and visualization skills** useful for Data Analyst roles.
