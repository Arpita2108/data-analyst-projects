
import pandas as pd

# Sample sales data
data = {
    "Product": ["Laptop", "Phone", "Tablet", "Laptop", "Phone"],
    "Sales": [50000, 30000, 20000, 45000, 25000]
}

df = pd.DataFrame(data)

# Total sales
total_sales = df["Sales"].sum()
print("Total Sales:", total_sales)

# Sales by product
sales_by_product = df.groupby("Product")["Sales"].sum()
print("\nSales by Product:")
print(sales_by_product)

# Best selling product
best_product = sales_by_product.idxmax()
print("\nBest Selling Product:", best_product)
